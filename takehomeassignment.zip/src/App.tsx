
import { useState } from 'react';
import './App.css'
import EmployeeList from './components/EmployeeList'
import EmployeeForm from './components/EmployeeForm';
import type { FormData } from './utils/FormDataInterface';

function App() {

  const [employees, setEmployees] = useState<FormData[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editEmployee, setEditEmployee] = useState<FormData | null>(null);


  const handleAddEmployee = (formData: FormData) => {
    if (editEmployee) {

      setEmployees(prev => {
        // Step 1: make a copy of employees
        const updatedEmployees = [...prev];

        // Step 2: find the index of the employee to update
        const index = updatedEmployees.findIndex(emp => emp.id === formData.id);

        // Step 3: if found, replace with updated formData
        if (index !== -1) {
          updatedEmployees[index] = formData;
        }

        // Step 4: return new state
        return updatedEmployees;
      })

      setEditEmployee(null);

    } else {
      setEmployees((prev) => [...prev, formData]);
    }
    setShowForm(false);
  };

  const handleDeleteEmployee = (id: string) => {
    const filteredEmployee = employees.filter(item => item.id !== id)
    setEmployees(filteredEmployee)
  };

  const handleEditEmployee = (id: string) => {
    const editEmployee = employees.find(item => item.id === id);
    if (editEmployee) {
      setEditEmployee(editEmployee);
      setShowForm(true);
    }
  }; 

  return (
    <div className="App">
      {showForm ? (
        <EmployeeForm addEmployee={handleAddEmployee} employee={editEmployee} />
      ) : (
        <>
          <EmployeeList employees={employees} onDelete={handleDeleteEmployee} onEdit={handleEditEmployee} />
          <button onClick={() => { setEditEmployee(null); setShowForm(true); }}>ADD EMPLOYEE FORM</button>
        </>
      )}
    </div>
  );
}

export default App
