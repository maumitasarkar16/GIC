import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';

// test('add a new employee', () => {
//   render(<App />);

//   // Open form
//   fireEvent.click(screen.getByText(/add employee form/i));

//   // Fill form
//   fireEvent.change(screen.getByLabelText(/first name/i), { target: { value: 'Maumita' } });
//   fireEvent.change(screen.getByLabelText(/last name/i), { target: { value: 'Sarkar' } });
//   fireEvent.change(screen.getByLabelText(/email/i), { target: { value: 'maumita@gmail.com' } });
//   fireEvent.change(screen.getByLabelText(/phone/i), { target: { value: '82145842' } });

//   // Set dates
//   fireEvent.change(screen.getByLabelText(/date of birth/i), { target: { value: '1997-10-01' } });
//   fireEvent.change(screen.getByLabelText(/date of joining/i), { target: { value: '2020-005-11' } });

//   // Submit
//   fireEvent.click(screen.getByText(/add employee$/i));

//   // Check if employee appears in list
//   expect(screen.getByText(/Maumita/i)).toBeInTheDocument();
//   expect(screen.getByText(/Sarkar/i)).toBeInTheDocument();
// });

test('shows validation errors', () => {
  render(<App />);
   fireEvent.click(screen.getByText(/add employee form/i));
   fireEvent.click(screen.getByText(/add employee$/i));

  expect(screen.getByText(/first name is required/i)).toBeInTheDocument();
  expect(screen.getByText(/last name is required/i)).toBeInTheDocument();
  expect(screen.getByText(/email is required/i)).toBeInTheDocument();
  expect(screen.getByText(/phone number is required/i)).toBeInTheDocument();
});
