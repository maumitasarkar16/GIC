import { Box, Button, FormControl, FormControlLabel, FormLabel, Radio, RadioGroup, TextField } from "@mui/material"
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { useEffect, useState } from "react";
import dayjs, { Dayjs } from "dayjs";
import type { FormData, FormErrors } from '../utils/FormDataInterface';

//create a basic employee form
//install mui and style the form according to mui
//validate the form  fields
//submit it and set the values in state variable and pass it in the form

//after submition show list of the employee with a column for edit and delete
//edit the same form , populate the saved data, and update state variables 
//delete the employee and refresh list

//write test cases


interface Props {
    addEmployee: (formData: FormData) => void;
    employee?: FormData | null;
}

const EmployeeForm = ({ addEmployee, employee }: Props) => {

    const [formData, setFormData] = useState<FormData>(employee || {
        id: "",
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        gender: "female",
        dateOfBirth: null,
        dateOfJoining: null,
    })
    const [errors, setErrors] = useState<FormErrors>({});
    const emailRegex = /\S+@\S+\.\S+/;
    const sgPhoneRegex = /^[689]\d{7}$/;

    const [isEditing, setIsEditing] = useState(false);

    //updates the field values
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData((prev) => ({
            ...prev,
            [e.target.name]: e.target.value
        })
        )
    }

    const handleDateChange = (name: string, value: Dayjs | null) => {
        setFormData((prev) => ({
            ...prev,
            [name]: value ? value.toISOString() : null
        })
        )
    }

    useEffect(() => {
        if (employee) {
            setFormData(employee);
            setIsEditing(true); // <-- important
        } else {
            setFormData({
                id: Date.now().toString(),
                firstName: "",
                lastName: "",
                email: "",
                phone: "",
                gender: "female",
                dateOfBirth: null,
                dateOfJoining: null,
            });
            setIsEditing(false);
        }
    }, [employee]);

    //submitting the form values 
    const handleAddEmployee = () => {
        if (validateForm()) {
            if (isEditing) {
                // Update existing employee
                addEmployee(formData); // addEmployee function updates by ID
                setIsEditing(false);
            } else {
                // Add new employee
                addEmployee({ ...formData, id: Date.now().toString() });
            }
            setFormData({
                id: isEditing ? formData.id : Date.now().toString(),
                firstName: "",
                lastName: "",
                email: "",
                phone: "",
                gender: "female",
                dateOfBirth: null,
                dateOfJoining: null,
            });
        }
    }

    const validateForm = () => {
        const errors: FormErrors = {};

        // First Name
        if (!formData.firstName) {
            errors.firstName = "First name is required";
        } else if (formData.firstName.length < 6 || formData.firstName.length > 10) {
            errors.firstName = "First name must be 6-10 characters";
        }

        // Last Name
        if (!formData.lastName) {
            errors.lastName = "Last name is required";
        } else if (formData.lastName.length < 6 || formData.lastName.length > 10) {
            errors.lastName = "Last name must be 6-10 characters";
        }

        // Email
        if (!formData.email) {
            errors.email = "Email is required";
        } else if (!emailRegex.test(formData.email)) {
            errors.email = "Invalid email format";
        }

        // Phone
        if (!formData.phone) {
            errors.phone = "Phone number is required";
        } else if (!sgPhoneRegex.test(formData.phone)) {
            errors.phone = "Invalid Singapore phone number";
        }

        // Date of Birth
        if (!formData.dateOfBirth) errors.dateOfBirth = "Date of Birth is required";

        // Joining Date
        if (!formData.dateOfJoining) {
            errors.dateOfJoining = "Joining Date is required";
        } else if (
            formData.dateOfBirth &&
            dayjs(formData.dateOfJoining).isBefore(dayjs(formData.dateOfBirth))
        ) {
            errors.dateOfJoining = "Joining date must be after Date of Birth";
        }

        setErrors(errors);
        return Object.keys(errors).length === 0;
    };

    return (
        <>
            <h1>Employee Form</h1>
            <Box component="form" display="flex" flexDirection="column" gap={2}>
                <TextField label="First Name" name="firstName" value={formData.firstName} onChange={handleChange} error={!!errors.firstName} helperText={errors.firstName} />
                <TextField label="Last Name" name="lastName" value={formData.lastName} onChange={handleChange} error={!!errors.lastName} helperText={errors.lastName} />
                <TextField label="Email" name="email" value={formData.email} onChange={handleChange} error={!!errors.email}
                    helperText={errors.email} />
                <TextField label="Phone" name="phone" value={formData.phone} onChange={handleChange} error={!!errors.phone}
                    helperText={errors.phone} />

                <FormControl>
                    <FormLabel>Gender</FormLabel>
                    <RadioGroup value={formData.gender} name="gender" onChange={handleChange} row>
                        <FormControlLabel value="female" control={<Radio />} label="Female"></FormControlLabel>
                        <FormControlLabel value="male" control={<Radio />} label="Male"></FormControlLabel>
                    </RadioGroup>
                </FormControl>

                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker label="Date of Birth" name="dateOfBirth" value={formData.dateOfBirth ? dayjs(formData.dateOfBirth) : null} onChange={(value) => handleDateChange("dateOfBirth", value)} slotProps={{
                        textField: {
                            error: !!errors.dateOfBirth,
                            helperText: errors.dateOfBirth,
                        },
                    }} />
                </LocalizationProvider>

                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker label="Date of Joining" name="dateOfJoining" value={formData.dateOfJoining ? dayjs(formData.dateOfJoining) : null} onChange={(value) => handleDateChange("dateOfJoining", value)} slotProps={{
                        textField: {
                            error: !!errors.dateOfJoining,
                            helperText: errors.dateOfJoining,
                        },
                    }} />
                </LocalizationProvider>

                <Button onClick={handleAddEmployee}>{isEditing ? "Update Employee" : "Add Employee"}</Button>
            </Box>

        </>

    )
}
export default EmployeeForm

