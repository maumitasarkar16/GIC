import { Table, TableHead, TableRow, TableCell, TableBody, Button } from "@mui/material";
import type { FormData } from '../utils/FormDataInterface';


interface EmployeeListProps {
  employees: FormData[];
  onDelete: (id: string) => void;
  onEdit: (id: string) => void;
}

const EmployeeList = ({employees, onDelete, onEdit}: EmployeeListProps) => {

  return (
    <Table>
      <TableHead>
        <TableRow>
          <TableCell>First Name</TableCell>
          <TableCell>Last Name</TableCell>
          <TableCell>Email</TableCell>
          <TableCell>Phone</TableCell>
          <TableCell>Gender</TableCell>
          <TableCell>DOB</TableCell>
          <TableCell>Joining Date</TableCell>
          <TableCell>Actions</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {employees.map((emp, index) => (
          <TableRow key={index}>
            <TableCell>{emp.firstName}</TableCell>
            <TableCell>{emp.lastName}</TableCell>
            <TableCell>{emp.email}</TableCell>
            <TableCell>{emp.phone}</TableCell>
            <TableCell>{emp.gender}</TableCell>
            <TableCell>{emp.dateOfBirth}</TableCell>
            <TableCell>{emp.dateOfJoining}</TableCell>
            <TableCell>
              <Button color="error" onClick={() => onDelete(emp.id)}>Delete</Button> | <Button color="error" onClick={() => onEdit(emp.id)}>Edit</Button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>  
  );

}
export default EmployeeList