export interface FormData {
    id: string; 
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    gender: "male" | "female" | "other";
    dateOfBirth: string | null;
    dateOfJoining: string | null;
}

export interface FormErrors {
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    dateOfBirth?: string;
    dateOfJoining?: string;
}